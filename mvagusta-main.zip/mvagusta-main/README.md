Hello there! 
This is my first PHP project.

- Pre-requisites:
  - Xampp
  - Php (latest)
- How to install and use this:
  - Step 1: Download the zip folder and extract into C:/xampp/htdocs/
  - Step 2: Start up Apache server and MySql server
  - Step 3: Open up phpmyadmin using the admin button related to mysql
  - Step 4: Open SQL tab and paste the contents of sql file
  - Step 5: Open (http://localhost/bike_company/) in a new tab
